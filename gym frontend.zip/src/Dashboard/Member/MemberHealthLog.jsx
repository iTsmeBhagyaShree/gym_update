import React, { useState, useEffect } from "react";
import axiosInstance from "../../Api/axiosInstance";

const MemberHealthLog = () => {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(false);

  const fetchLogs = async () => {
    try {
      setLoading(true);
      const user = JSON.parse(localStorage.getItem("user") || "{}");
      if (!user.id) return;
      
      const actualMemberId = user.memberId || user.id;
      const response = await axiosInstance.get(`health/member/${actualMemberId}`);
      if (response.data && response.data.logs) {
        setLogs(response.data.logs);
      }
    } catch (error) {
      console.error("Error fetching health logs:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  return (
    <div className="container-fluid py-4">
      <h2 className="mb-4" style={{ color: "#2B3674", fontWeight: "bold" }}>
        My Health & BMI Log
      </h2>

      <div className="card shadow-sm border-0" style={{ borderRadius: "15px" }}>
        <div className="card-header bg-white border-0 pt-4 pb-0">
          <h5 style={{ fontWeight: "600", color: "#4318FF" }}>Health History</h5>
        </div>
        <div className="card-body">
          {loading ? (
            <div className="text-center py-4"><div className="spinner-border text-primary" /></div>
          ) : (
            <div className="table-responsive">
              <table className="table align-middle">
                <thead className="bg-light">
                  <tr>
                    <th>Date</th>
                    <th>Weight (kg)</th>
                    <th>Height (cm)</th>
                    <th>BMI</th>
                    <th>Status</th>
                    <th>Diet / Notes</th>
                  </tr>
                </thead>
                <tbody>
                  {logs.length > 0 ? (
                    logs.map((log) => (
                      <tr key={log.id}>
                        <td>{new Date(log.recordedAt || log.createdAt || new Date()).toLocaleDateString()}</td>
                        <td>{log.weight || '-'}</td>
                        <td>{log.height || '-'}</td>
                        <td className="fw-bold">{log.bmi || '-'}</td>
                        <td>
                          {log.bmiStatus && (
                            <span className={`badge ${log.bmiStatus === 'Normal' ? 'bg-success' : log.bmiStatus === 'Underweight' ? 'bg-warning' : 'bg-danger'}`}>
                              {log.bmiStatus}
                            </span>
                          )}
                        </td>
                        <td>
                          {log.dietChart && <p className="mb-1"><strong>Diet:</strong> {log.dietChart}</p>}
                          {log.notes && <p className="mb-0 text-muted small">{log.notes}</p>}
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr><td colSpan="6" className="text-center py-3">No health logs found.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MemberHealthLog;
