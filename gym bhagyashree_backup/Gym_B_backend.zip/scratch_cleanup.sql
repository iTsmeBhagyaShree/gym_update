START TRANSACTION;

-- 1. Unassign deleted staff from leads to prevent foreign key constraint failures
UPDATE leads SET assignedToStaffId = NULL WHERE assignedToStaffId NOT IN (25, 26, 27, 54);

-- 2. Reassign leads of deleted admins to the main admin (90) to preserve all lead records
UPDATE leads SET adminId = 90 WHERE adminId NOT IN (67, 90, 163, 93, 102, 103, 229, 104);

-- 3. Delete salary records of deleted staff
DELETE FROM salary WHERE staffId NOT IN (25, 26, 27, 54);

-- 4. Delete housekeeping attendance for deleted staff/users
DELETE FROM housekeepingattendance WHERE staffId NOT IN (25, 26, 27, 54) OR createdById NOT IN (67, 90, 163, 93, 102, 103, 229, 104);

-- 5. Delete housekeeping schedule for deleted staff/users
DELETE FROM housekeepingschedule WHERE staffId NOT IN (25, 26, 27, 54) OR createdById NOT IN (67, 90, 163, 93, 102, 103, 229, 104);

-- 6. Delete staff attendance for deleted staff
DELETE FROM staffattendance WHERE staffId NOT IN (25, 26, 27, 54);

-- 7. Delete shifts for deleted staff or created by deleted users
DELETE FROM shifts WHERE staffIds NOT IN (25, 26, 27, 54) OR createdById NOT IN (67, 90, 163, 93, 102, 103, 229, 104);

-- 8. Delete assessments for deleted members
DELETE FROM member_assessments WHERE memberId != 156;

-- 9. Delete health log for deleted members
DELETE FROM member_health_log WHERE memberId != 156;

-- 10. Delete bodybuilding logs for deleted members
DELETE FROM member_bodybuilding_logs WHERE memberId != 156;

-- 11. Delete attendance for deleted members
DELETE FROM memberattendance WHERE memberId != 156;

-- 12. Delete payments for deleted members
DELETE FROM payment WHERE memberId != 156;

-- 13. Delete bookings for deleted members
DELETE FROM booking WHERE memberId != 156;

-- 14. Delete booking requests for deleted members
DELETE FROM booking_requests WHERE memberId != 156;

-- 15. Delete diet plan assignments for deleted members
DELETE FROM dietplanassignment WHERE memberId != 156;

-- 16. Delete workout plan assignments for deleted members
DELETE FROM workoutplanassignment WHERE memberId != 156;

-- 17. Delete used qr nonces for deleted members
DELETE FROM used_qr_nonces WHERE memberId != 156;

-- 18. Delete notification logs for deleted members
DELETE FROM notificationlog WHERE memberId != 156 AND memberId IS NOT NULL;

-- 19. Delete renewal requests for deleted members
DELETE FROM membership_renewal_requests WHERE memberId != 156;

-- 20. Delete plan assignments for deleted members
DELETE FROM member_plan_assignment WHERE memberId != 156;

-- 21. Delete group class bookings for deleted members
DELETE FROM group_class_bookings WHERE memberId != 156;

-- 22. Delete pt bookings for deleted members
DELETE FROM pt_bookings WHERE memberId != 156;

-- 23. Delete unified bookings for deleted members or deleted trainers
DELETE FROM unified_bookings WHERE memberId != 156 OR trainerId NOT IN (67, 90, 163, 93, 102, 103, 229, 104);

-- 24. Delete class schedules for deleted trainers
DELETE FROM classschedule WHERE trainerId NOT IN (102, 93) AND trainerId IS NOT NULL;

-- 25. Delete sessions for deleted trainers
DELETE FROM session WHERE trainerId NOT IN (102, 93) AND trainerId IS NOT NULL;

-- 26. Delete saas payments for deleted admins
DELETE FROM saas_payments WHERE adminId NOT IN (67, 90, 163, 93, 102, 103, 229, 104);

-- 27. Delete app settings for deleted admins
DELETE FROM app_settings WHERE adminId NOT IN (67, 90, 163, 93, 102, 103, 229, 104);

-- 28. Delete tasks assigned to deleted users or created by deleted users
DELETE FROM tasks WHERE (assignedTo NOT IN (67, 90, 163, 93, 102, 103, 229, 104) AND assignedTo IS NOT NULL) OR createdById NOT IN (67, 90, 163, 93, 102, 103, 229, 104);

-- 29. Delete alerts for deleted staff or deleted members
DELETE FROM alert WHERE (staffId NOT IN (67, 90, 163, 93, 102, 103, 229, 104) AND staffId IS NOT NULL) OR (memberId != 156 AND memberId IS NOT NULL);

-- 30. Clean member plans: assign deleted admins' plans to main admin (90), clear trainer associations for deleted trainers
UPDATE memberplan SET adminId = 90 WHERE adminId NOT IN (67, 90, 163, 93, 102, 103, 229, 104);
UPDATE memberplan SET trainerId = NULL WHERE trainerId NOT IN (102, 93) AND trainerId IS NOT NULL;

-- 31. Delete extra member records
DELETE FROM member WHERE id != 156;

-- 32. Delete extra staff records (including duplicate staff ID 55)
DELETE FROM staff WHERE id NOT IN (25, 26, 27, 54);

-- 33. Delete extra user records
DELETE FROM user WHERE id NOT IN (67, 90, 163, 93, 102, 103, 229, 104);

COMMIT;
